import type { Metadata } from "next";
import { Conversa } from "@/components/site/blocks";
import Hero from "@/components/site/Hero";
import { Card, FaqList, Grid, Head, Quote, Section, Stat, Steps } from "@/components/site/ui";
import { MANDATE_QUOTES, STATS } from "@/content/site";

export const metadata: Metadata = {
  title: "Consultoria para mandatos",
  description: "Em 3 meses, sua equipe sai com prioridades claras, metas acompanhadas e mais capacidade de execução. Para mandatos federais, estaduais e municipais.",
  alternates: { canonical: "/mandatos/" },
};

export default function Mandatos() {
  return (
    <>
      <Hero
        actions={[{ label: "Agende uma conversa", href: "#conversa", arrow: true }, { label: "Como funciona", href: "#como", variant: "ghost" }]}
        backdrop="congresso"
        crumbs={[{ label: "Para mandatos" }]}
        lede="Em 3 meses, sua equipe sai com prioridades claras, metas acompanhadas e mais capacidade de execução. Para mandatos federais, estaduais e municipais, de qualquer partido do campo democrático."
        title="Um mandato planejado entrega o que prometeu."
      />
      <Section tone="surface">
        <Grid cols={4} min="12rem">
          <Stat label="de consultoria, com metodologia ágil" n="3 meses" />
          <Stat label="federal, estadual e municipal" n="3 esferas" />
          <Stat label="mandatos já atendidos" n={STATS.mandatos} />
          <Stat label="investimento, ou “sob consulta”" n="[faixa]" />
        </Grid>
      </Section>
      <Section id="como" tone="ink">
        <h2>Como funciona</h2>
        <Steps items={[
          { n: "1. Diagnóstico", title: "Um raio-x do mandato", text: "Avaliamos três eixos: liderança política, relevância de agendas e capacidade de execução da equipe." },
          { n: "2. Plano", title: "Prioridades e metas", text: "Desenhamos com a equipe um plano de curto, médio e longo prazo, com metas que dá para acompanhar." },
          { n: "3. Implementação", title: "Rotina de execução", text: "Implantamos rituais de acompanhamento e ferramentas de gestão adaptados à realidade do gabinete." },
        ]} />
      </Section>
      <Section>
        <Head title="Duas formas de trabalhar com a gente" />
        <Grid cols={2} min="18rem">
          <Card link={{ label: "Agendar uma conversa", href: "#conversa" }} title="Consultoria de Estratégia Política">
            Para o mandato inteiro: 3 meses de acompanhamento, do diagnóstico à rotina de metas. A equipe da Legisla trabalha lado a lado com o gabinete e se adapta à realidade de cada mandato.
          </Card>
          <Card chip={{ text: "Inscrições encerradas", open: false }} link={{ label: "Entrar na lista de espera", href: "/programa-pll/" }} title="Programa Lideranças Legislativas">
            Para chefias de gabinete de municípios com mais de 50 mil habitantes: imersão presencial de 2 dias e 4 meses de mentoria online. Participação gratuita.
          </Card>
        </Grid>
      </Section>
      <Section tone="paper">
        <div className="lg-head">
          <h2>Quem já trabalhou com a gente</h2>
          <a className="lg-link" href="https://legislabrasil.org/wp-content/uploads/2026/11/Caso-de-Sucesso-Lohanna.pdf" rel="noopener" target="_blank">Ler o caso completo da Lohanna</a>
        </div>
        <Grid cols={2} min="18rem">{MANDATE_QUOTES.map((q) => <Quote key={q.name} t={q} />)}</Grid>
      </Section>
      <Section>
        <h2>Perguntas frequentes</h2>
        <FaqList items={[
          { q: "Vocês trabalham com qualquer partido?", a: "Trabalhamos com todo o espectro político comprometido com a democracia. Não atendemos partidos ou mandatos que atuem contra o Estado Democrático de Direito." },
          { q: "Quanto custa a consultoria?", a: "[Faixa de investimento ou explicação de como o valor é definido.]" },
          { q: "Quanto tempo dura e quanto exige da equipe?", a: "A consultoria dura 3 meses. [Quantas horas por semana a equipe do gabinete precisa dedicar.]" },
          { q: "Atendem vereadores e mandatos fora de São Paulo?", a: "Sim. Trabalhamos com mandatos federais, estaduais e municipais de todas as regiões do Brasil." },
        ]} />
      </Section>
      <Conversa title="Vamos conversar sobre o seu mandato" />
    </>
  );
}
