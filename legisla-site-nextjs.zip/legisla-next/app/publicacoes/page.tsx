import type { Metadata } from "next";
import { Newsletter } from "@/components/site/blocks";
import Hero from "@/components/site/Hero";
import { Btn, Grid, Head, PublicationCard, Section } from "@/components/site/ui";
import { PUBLICATIONS } from "@/content/site";

export const metadata: Metadata = {
  title: "Pesquisas e guias",
  description: "Pesquisas, guias e ferramentas da Legisla Brasil para decodificar o Legislativo, abertos a agentes políticos e à sociedade civil.",
  alternates: { canonical: "/publicacoes/" },
};

export default function Publicacoes() {
  return (
    <>
      <Hero backdrop="documento" crumbs={[{ label: "Pesquisas e guias" }]}
        lede="Pesquisas, guias e ferramentas feitos a partir de dados e da nossa experiência com mandatos e partidos. Tudo aberto, para agentes políticos e para a sociedade civil."
        title="Conhecimento para decodificar o Legislativo." />
      <Section tone="surface">
        <Head side="Pesquisas, guias e ferramentas, da mais recente para a mais antiga." title="Todas as publicações" />
        <Grid cols={4} min="15rem">{PUBLICATIONS.map((p) => <PublicationCard key={p.title} pub={p} />)}</Grid>
      </Section>
      <Section>
        <div className="lg-split">
          <h2>Quer colaborar em uma pesquisa ou artigo?</h2>
          <div>
            <p className="lg-lede">Se você estuda o Legislativo ou quer compartilhar um estudo com a Comunidade Legisla, fale com a gente.</p>
            <div className="lg-actions"><Btn href="/contato/">Falar com a equipe</Btn><Btn href="/na-midia/" variant="ghost">Ver a Legisla na mídia</Btn></div>
          </div>
        </div>
      </Section>
      <Newsletter />
    </>
  );
}
