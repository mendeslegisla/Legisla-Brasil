import type { Metadata } from "next";
import Form from "@/components/site/Form";
import Hero from "@/components/site/Hero";
import { Card, FaqList, Grid, Head, Section, Steps } from "@/components/site/ui";

export const metadata: Metadata = {
  title: "Programa Nossas Excelências",
  description: "O primeiro programa do Brasil voltado a lideranças partidárias: gestão interna, inovação e representatividade nos partidos.",
  alternates: { canonical: "/programa-nex/" },
};

export default function NEx() {
  return (
    <>
      <Hero
        actions={[{ label: "Quero ser avisado(a)", href: "#interesse", arrow: true }, { label: "Como funciona", href: "#formato", variant: "ghost" }]}
        backdrop="hemiciclo" crumbs={[{ label: "Para partidos", href: "/partidos/" }, { label: "Programa NEx" }]}
        lede="O primeiro programa do Brasil voltado a lideranças partidárias. Fortalece dirigentes nos desafios de gestão interna, inovação e representatividade, para que boas práticas sejam institucionalizadas nos partidos."
        status={{ text: "[Status da próxima edição]" }}
        title="Programa Nossas Excelências" />
      <Section tone="surface">
        <div className="lg-split">
          <h2>Partidos organizam a democracia</h2>
          <p className="lg-lede">Dirigentes partidários elaboram planos de governo, promovem formação política e montam as chapas que elegem nossos representantes. O NEx apoia essas lideranças a levar inclusão, inovação, representatividade e uma gestão mais democrática para dentro dos partidos.</p>
        </div>
      </Section>
      <Section id="formato" tone="ink">
        <h2>Como funciona</h2>
        <Steps items={[
          { n: "1. Formação", title: "Encontros presenciais e remotos", text: "Aulas expositivas, painéis de discussão e dinâmicas mão na massa, com palestrantes nacionais e internacionais." },
          { n: "2. Projeto", title: "Uma mudança no seu partido", text: "Cada participante desenha um projeto para institucionalizar uma boa prática na sua legenda." },
          { n: "3. Implementação", title: "Acompanhamento da Legisla", text: "Projetos selecionados podem ser implementados com acompanhamento da equipe de Partidos da Legisla." },
        ]} />
      </Section>
      <Section>
        <Head side="A metodologia foi criada pela Legisla a partir de experiências bem-sucedidas de gestão partidária no Brasil e no mundo." title="Quem participa" />
        <Grid cols={3}>
          <Card title="Dirigentes partidários">Com ênfase em secretárias e secretários nacionais e estaduais e em presidentes de diretórios.</Card>
          <Card title="De todo o campo democrático">Lideranças de partidos diferentes, que trocam experiências entre si ao longo do programa.</Card>
          <Card title="Por indicação">As vagas são preenchidas por indicação. [Confirmar as categorias de indicação da próxima edição.]</Card>
        </Grid>
      </Section>
      <Section tone="paper">
        <Head title="Resultados" />
        <Grid cols={3}>
          <Card title="PSD MG, Impulso Jovem">O setorial de juventude do PSD de Minas Gerais foi finalista do NEx. O projeto, que fortalece a atuação jovem dentro do partido, está em execução com apoio da Legisla.</Card>
          <Card title="Eleições municipais de 2024">Uma edição reuniu 30 lideranças com foco em tornar as eleições municipais mais inclusivas.</Card>
          <Card title="[Outro resultado]">[Um caso ou número da edição mais recente.]</Card>
        </Grid>
      </Section>
      <Section>
        <h2>Perguntas frequentes</h2>
        <FaqList items={[
          { q: "Para quem é o NEx?", a: "Para dirigentes partidários, especialmente secretárias e secretários nacionais e estaduais e presidentes de diretórios, de partidos comprometidos com a democracia." },
          { q: "Como faço para participar?", a: "As vagas são preenchidas por indicação. Deixe seu contato na lista de interesse e avisamos quando a próxima edição abrir." },
          { q: "O programa tem custo?", a: "[Confirmar se a participação é gratuita e o que está incluído.]" },
          { q: "Qual é a duração?", a: "[Datas e duração da próxima edição.]" },
        ]} />
      </Section>
      <Section id="interesse" tone="wine">
        <div className="lg-split">
          <div>
            <h2>Avise-me da próxima edição</h2>
            <p className="lg-lede" style={{ marginTop: "1.25rem" }}>Deixe seu contato e avisamos quando as indicações abrirem.</p>
          </div>
          <div className="lg-form-box">
            <Form consent="Autorizo a Legisla a me avisar sobre o programa, conforme a" fields={[
              { name: "nome", label: "Nome", required: true, autoComplete: "name", pair: true },
              { name: "email", label: "E-mail", type: "email", required: true, autoComplete: "email", pair: true },
              { name: "partido", label: "Partido", pair: true },
              { name: "cargo", label: "Cargo no partido", pair: true },
            ]} id="interesse-nex" submit="Quero ser avisado(a)" />
          </div>
        </div>
      </Section>
    </>
  );
}
