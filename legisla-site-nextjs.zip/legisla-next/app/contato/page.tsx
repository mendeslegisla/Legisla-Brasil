import type { Metadata } from "next";
import Form from "@/components/site/Form";
import Hero from "@/components/site/Hero";
import { Card, Grid, Head, Section } from "@/components/site/ui";
import { SITE } from "@/content/site";

export const metadata: Metadata = {
  title: "Contato",
  description: "Fale com a Legisla Brasil por e-mail, WhatsApp ou formulário. Imprensa: assessoria da Contê.",
  alternates: { canonical: "/contato/" },
};

export default function Contato() {
  return (
    <>
      <Hero backdrop="rede" crumbs={[{ label: "Contato" }]}
        lede={`Escolha o canal mais prático ou deixe uma mensagem no formulário. Respondemos em até ${SITE.responseDays} dias úteis.`} title="Fale com a Legisla." />
      <Section tone="surface">
        <Head title="Canais de contato" />
        <Grid cols={4} min="13rem">
          <Card link={{ label: SITE.email, href: `mailto:${SITE.email}` }} title="E-mail">Para qualquer assunto, incluindo parcerias e doações.</Card>
          <Card link={{ label: SITE.whatsapp.label, href: SITE.whatsapp.href }} title="WhatsApp">Para conversas rápidas. [Horário de atendimento]</Card>
          <Card link={{ label: SITE.press.email, href: `mailto:${SITE.press.email}` }} title="Imprensa">Assessoria da {SITE.press.name}: {SITE.press.phone}.</Card>
          <Card link={{ label: "Instagram", href: SITE.social.instagram }} title="Redes">Acompanhe novidades, pesquisas e programas abertos.</Card>
        </Grid>
      </Section>
      <Section id="mensagem">
        <div className="lg-split">
          <div>
            <h2>Deixe uma mensagem</h2>
            <p className="lg-lede" style={{ marginTop: "1.25rem" }}>Conte sobre o que quer falar e a mensagem chega direto para a pessoa certa da equipe.</p>
            <p className="lg-muted" style={{ marginTop: "1rem" }}>Procurando um serviço? Veja as páginas <a href="/mandatos/">Para mandatos</a> e <a href="/partidos/">Para partidos</a>.</p>
          </div>
          <div className="lg-form-box">
            <Form
              fields={[
                { name: "assunto", label: "Assunto", type: "select", options: ["Consultoria para mandato", "Trabalho com partido", "Comunidade Legisla", "Imprensa", "Doação ou parceria", "Outro assunto"] },
                { name: "nome", label: "Nome", required: true, autoComplete: "name", pair: true },
                { name: "email", label: "E-mail", type: "email", required: true, autoComplete: "email", pair: true },
                { name: "mensagem", label: "Mensagem", type: "textarea", required: true },
              ]}
              id="contato" newsletterOptIn submit="Enviar mensagem"
            />
          </div>
        </div>
      </Section>
    </>
  );
}
