import type { Metadata } from "next";
import Form from "@/components/site/Form";
import Hero from "@/components/site/Hero";
import { Card, FaqList, Grid, Head, Section, Steps } from "@/components/site/ui";

export const metadata: Metadata = {
  title: "Programa Lideranças Legislativas",
  description: "Programa que forma chefias de gabinete na metodologia de planejamento estratégico da Legisla Brasil. Imersão de 2 dias e 4 meses de mentoria.",
  alternates: { canonical: "/programa-pll/" },
};

export default function PLL() {
  return (
    <>
      <Hero
        actions={[{ label: "Entrar na lista de espera", href: "#espera", arrow: true }, { label: "Como funciona", href: "#formato", variant: "ghost" }]}
        backdrop="congresso" crumbs={[{ label: "Para mandatos", href: "/mandatos/" }, { label: "Programa Lideranças Legislativas" }]}
        lede="Forma chefias de gabinete na metodologia de planejamento estratégico da Legisla Brasil, para que os mandatos entreguem o que a população precisa."
        status={{ text: "Inscrições encerradas. A 5ª edição terminou em julho de 2026.", open: false }}
        title="Programa Lideranças Legislativas" />
      <Section id="formato" tone="ink">
        <h2>Como funciona</h2>
        <Steps items={[
          { n: "2 dias", title: "Imersão presencial", text: "Em São Paulo, cada participante desenvolve o planejamento estratégico do seu mandato com a metodologia da Legisla." },
          { n: "4 meses", title: "Mentorias online", text: "Encontros individuais de 1 hora com especialistas da Legisla para implementar o plano no gabinete." },
          { n: "Depois", title: "Comunidade Legisla", text: "Quem conclui passa a fazer parte da Comunidade, com encontros e trocas com profissionais de todo o Brasil." },
        ]} />
      </Section>
      <Section tone="surface">
        <Head title="O que você vai aprender" />
        <Grid cols={3}>
          <Card title="Planejamento estratégico">Desenvolver e implementar um plano para o mandato, com metas claras.</Card>
          <Card title="Gestão de equipe">Delegar tarefas, acompanhar metas e conduzir reuniões de monitoramento.</Card>
          <Card title="Comunicação">Melhorar a comunicação interna e externa do gabinete.</Card>
        </Grid>
      </Section>
      <Section>
        <h2>Perguntas frequentes</h2>
        <FaqList items={[
          { q: "Para quem é o programa?", a: "Para chefias de gabinete de vereadores de municípios com mais de 50 mil habitantes." },
          { q: "O programa é gratuito?", a: "Sim. A Legisla custeia o pernoite, o café da manhã e o almoço da imersão. O participante arca com o deslocamento até São Paulo e o jantar." },
          { q: "Não posso ir aos dois dias presenciais. Posso me inscrever?", a: "Não. Para participar é preciso se comprometer com a imersão e com as mentorias online." },
          { q: "Quanto tempo dura?", a: "São 4 meses no total: a imersão de 2 dias e as mentorias online nos meses seguintes." },
        ]} />
      </Section>
      <Section id="espera" tone="wine">
        <div className="lg-split">
          <div>
            <h2>Avise-me da próxima edição</h2>
            <p className="lg-lede" style={{ marginTop: "1.25rem" }}>Deixe seu contato e avisamos assim que as inscrições abrirem.</p>
          </div>
          <div className="lg-form-box">
            <Form consent="Autorizo a Legisla a me avisar sobre o programa, conforme a" fields={[
              { name: "nome", label: "Nome", required: true, autoComplete: "name", pair: true },
              { name: "email", label: "E-mail", type: "email", required: true, autoComplete: "email", pair: true },
              { name: "cidade", label: "Município e UF do mandato" },
            ]} id="espera-pll" submit="Entrar na lista de espera" />
          </div>
        </div>
      </Section>
    </>
  );
}
