import type { Metadata } from "next";
import ScrollIndex from "@/components/kokonutui/scroll-index";
import { Donate } from "@/components/site/blocks";
import Hero from "@/components/site/Hero";
import { Card, FaqList, Grid, Head, Rows, Section, Stat } from "@/components/site/ui";
import { AUDITS, IMPACT_REPORTS, SITE, STATS } from "@/content/site";

export const metadata: Metadata = {
  title: "Transparência",
  description: "Intenções, financiamento, teoria da mudança, relatórios de impacto, auditorias independentes e código de conduta da Legisla Brasil.",
  alternates: { canonical: "/transparencia/" },
};

export default function Transparencia() {
  return (
    <>
      <Hero backdrop="documento" crumbs={[{ label: "Quem somos", href: "/quem-somos/" }, { label: "Transparência" }]}
        lede={<>A transparência é a base do trabalho sério na política. Aqui estão nossas intenções, como financiamos o trabalho e todos os relatórios. Se não encontrar algo, <a href="/contato/">fale com a gente</a>.</>}
        title="Transparência" />
      <Section tone="surface">
        <div className="lg-split">
          <div>
            <h2>Nossas intenções</h2>
            <p style={{ marginTop: "1.5rem" }}>Trabalhamos para fortalecer a democracia, apoiando quem já está no poder político institucional. Para o campo democrático funcionar, todos os jogadores precisam jogar bem e entender as regras do jogo.</p>
            <p style={{ marginTop: "1rem" }}>Por isso atuamos de forma <strong>suprapartidária, sem defender agendas específicas</strong>.</p>
          </div>
          <div>
            <h2>Nossos recursos</h2>
            <p style={{ marginTop: "1.5rem" }}>O financiamento é misto: doações de pessoas e instituições filantrópicas, nacionais e internacionais, e a venda de serviços para mandatos e partidos.</p>
            <Grid cols={2} min="9rem"><Stat label="doações" n="70%" /><Stat label="serviços" n="30%" /></Grid>
            <p className="lg-small lg-muted" style={{ marginTop: "1rem" }}>Proporção média dos últimos anos. Em [ano] nossos doadores foram: [atualizar lista]. Em 2023: Fundação Lemann, VélezReyes+, Open Society Foundations, Instituto Ibirapitanga, Instituto Galo da Manhã e Instituto Betty Jacob Lafer, além de pessoas físicas.</p>
          </div>
        </div>
      </Section>
      <Section tone="ink">
        <Head side="O que fazemos em cada frente, e o que queremos ver acontecer." title="Teoria da mudança" />
        <Grid cols={3}>
          <Card title="Conhecimento">Geramos dados e evidências sobre como políticos podem ser mais representativos e efetivos. <strong>Objetivo:</strong> aumentar o nível médio de produtividade dos gabinetes mais relevantes do Brasil.</Card>
          <Card title="Instituições">Oferecemos consultorias e ferramentas de gestão e estratégia, e viabilizamos programas partidários de inclusão. <strong>Objetivo:</strong> partidos institucionalizando a participação de grupos sub-representados.</Card>
          <Card title="Pessoas">Fomentamos espaços de troca e desenvolvimento de atores democráticos. <strong>Objetivo:</strong> uma massa crítica de parlamentares com práticas efetivas, inovadoras e inclusivas.</Card>
        </Grid>
      </Section>
      <Section id="relatorios">
        {/* Índice que acompanha a rolagem (scroll-index, do Kokonut UI) */}
        <ScrollIndex scroller="window" selector="h2">
          <Head title="Relatórios de impacto" />
          <Rows items={IMPACT_REPORTS} />
          <div style={{ marginTop: "clamp(3.5rem, 6vw, 5rem)" }}><Head title="Auditorias independentes" /></div>
          <Rows items={AUDITS} />
          <div style={{ marginTop: "clamp(3.5rem, 6vw, 5rem)" }}><Head title="Integridade" /></div>
          <Rows items={[
            { year: "Documento", title: "Código de Conduta da Legisla Brasil", href: SITE.conduct, note: "Vale para todas as relações da Legisla" },
            { year: "Documento", title: "Política de Privacidade", href: "/politica-de-privacidade/", note: "Como tratamos dados pessoais" },
          ]} />
          <div style={{ marginTop: "clamp(3.5rem, 6vw, 5rem)" }}><Head title="Perguntas frequentes" /></div>
          <FaqList items={[
            { q: "O que quer dizer ser suprapartidário? Vocês trabalham com qualquer partido?", a: "Trabalhamos com todo o espectro político e ideológico comprometido com uma agenda democrática. Não trabalhamos com partidos ou parlamentares que atuem contra o Estado Democrático de Direito." },
            { q: "Vocês fazem lobby ou advocacy por alguma pauta?", a: "A nossa agenda é a democracia. Colocamos nossas metodologias a serviço de partidos e mandatos com pautas distintas entre si. A única pauta que defendemos diretamente é o fortalecimento de uma democracia representativa." },
            { q: "Qual é a ideologia da Legisla?", a: "A Legisla não defende nenhuma ideologia." },
            { q: "Quem trabalha na Legisla? A Legisla tem dono?", a: "A Legisla foi fundada por Luciana Elmais, Caio Rolim e Ana Kuntz. Hoje Luciana atua como presidente do Conselho, e a direção é de Fernando Moura, diretor executivo, e Lana Faria, diretora de operações." },
            { q: "Há quantos anos a Legisla existe?", a: "Fundada informalmente em agosto de 2017 e registrada oficialmente em abril de 2018." },
            { q: "Com quem vocês já trabalharam?", a: `Com ${STATS.mandatos} parlamentares de ${STATS.partidos} partidos diferentes. Veja casos na página Para mandatos.` },
          ]} />
        </ScrollIndex>
      </Section>
      <Donate />
    </>
  );
}
