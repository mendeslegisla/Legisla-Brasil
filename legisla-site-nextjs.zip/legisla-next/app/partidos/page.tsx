import type { Metadata } from "next";
import { Conversa } from "@/components/site/blocks";
import Hero from "@/components/site/Hero";
import { Btn, Card, Chip, Grid, Head, Section } from "@/components/site/ui";

export const metadata: Metadata = {
  title: "Soluções para partidos",
  description: "Atração de lideranças femininas, negras e jovens, desenho de agenda partidária e formação continuada para partidos do campo democrático.",
  alternates: { canonical: "/partidos/" },
};

const CASES = [
  { party: "PSB SP", challenge: "Organizar as metas do partido no estado.", done: "Planejamento estratégico seguido ao longo de 2022 e parte de 2023, com metas a cada quadrimestre.", result: "O plano foi executado integralmente e serviu de base para as metas seguintes." },
  { party: "Cidadania BA", challenge: "Formar lideranças femininas em Salvador.", done: "Facilitamos um módulo presencial do projeto Elas Lideram, da vereadora Isabela Sousa.", result: "[Resultado em números, a confirmar com o partido.]" },
  { party: "PSD MG", challenge: "Fortalecer a juventude dentro do partido.", done: "O setorial de juventude foi finalista do NEx com o projeto Impulso Jovem.", result: "Projeto em execução, com acompanhamento da Legisla." },
];

export default function Partidos() {
  return (
    <>
      <Hero
        actions={[{ label: "Agende uma conversa", href: "#conversa", arrow: true }, { label: "Ver soluções", href: "#solucoes", variant: "ghost" }]}
        backdrop="hemiciclo"
        crumbs={[{ label: "Para partidos" }]}
        lede="Ajudamos partidos a atrair e desenvolver lideranças de grupos sub-representados, organizar suas agendas e formar seus quadros."
        title="Partidos são os organizadores da democracia brasileira."
      />
      <Section id="solucoes" tone="surface">
        <Head side="Construímos com a direção partidária, a partir de um diagnóstico baseado em dados." title="Nossas soluções" />
        <Grid cols={3}>
          <Card title="Atração e desenvolvimento de lideranças">Programas para trazer lideranças femininas, negras e jovens para dentro do partido, com processos, campanhas e conteúdos que removem barreiras de representatividade.</Card>
          <Card title="Desenho de agenda partidária">Planos e programas para as agendas defendidas pelo partido, com base em experiências bem-sucedidas no Brasil e no mundo. Também apoiamos diretórios, fundações, setoriais e secretarias.</Card>
          <Card title="Formação continuada">Workshops e cursos para filiados e lideranças, feitos com o partido ou sua fundação: planejamento político, uso de dados, representatividade, gestão de mandatos e produtividade.</Card>
        </Grid>
      </Section>
      <Section tone="ink">
        <div className="lg-split">
          <h2>O primeiro programa voltado a lideranças partidárias</h2>
          <div>
            <p className="lg-lede">O Programa Nossas Excelências capacita líderes partidários para promover mudanças positivas que possam ser institucionalizadas nos seus partidos.</p>
            <div className="lg-actions"><Btn href="/programa-nex/" variant="light">Conhecer o NEx</Btn></div>
          </div>
        </div>
      </Section>
      <Section>
        <Head title="Casos com partidos" />
        <Grid cols={3}>
          {CASES.map((c) => (
            <article className="lg-card" key={c.party}>
              <Chip>{c.party}</Chip>
              <p><strong>Desafio.</strong> {c.challenge}</p>
              <p><strong>O que fizemos.</strong> {c.done}</p>
              <p><strong>Resultado.</strong> {c.result}</p>
            </article>
          ))}
        </Grid>
      </Section>
      <Conversa />
    </>
  );
}
