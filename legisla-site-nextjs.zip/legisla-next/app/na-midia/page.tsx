import type { Metadata } from "next";
import Hero from "@/components/site/Hero";
import { Head, Rows, Section } from "@/components/site/ui";
import { MEDIA, SITE } from "@/content/site";

export const metadata: Metadata = {
  title: "Legisla na mídia",
  description: "Artigos assinados pela equipe da Legisla Brasil e a cobertura da imprensa sobre as nossas pesquisas.",
  alternates: { canonical: "/na-midia/" },
};

export default function NaMidia() {
  return (
    <>
      <Hero backdrop="documento" crumbs={[{ label: "Legisla na mídia" }]}
        lede="Artigos assinados pela nossa equipe em veículos de todo o país e a cobertura da imprensa sobre as pesquisas da Legisla."
        title="O que escrevemos e o que dizem sobre nós." />
      <Section tone="surface">
        <Head title="Artigos da equipe" />
        <Rows items={MEDIA.artigos} />
      </Section>
      <Section>
        <Head title="Cobertura da imprensa" />
        <Rows items={MEDIA.imprensa} />
      </Section>
      <Section tone="ink">
        <div className="lg-split">
          <h2>Para jornalistas</h2>
          <div>
            <p className="lg-lede">Entrevistas, dados das pesquisas e posicionamentos: fale com a assessoria de imprensa da Legisla, a {SITE.press.name}.</p>
            <p style={{ marginTop: "1rem" }}><a href={`mailto:${SITE.press.email}`}>{SITE.press.email}</a> · {SITE.press.phone}</p>
          </div>
        </div>
      </Section>
    </>
  );
}
