import type { Metadata } from "next";
import Hero from "@/components/site/Hero";
import { Section } from "@/components/site/ui";

export const metadata: Metadata = {
  title: "Política de Privacidade",
  description: "Como a Legisla Brasil coleta, usa e protege dados pessoais, conforme a Lei Geral de Proteção de Dados.",
  alternates: { canonical: "/politica-de-privacidade/" },
};

export default function Privacidade() {
  return (
    <>
      <Hero backdrop="documento" crumbs={[{ label: "Política de Privacidade" }]}
        lede="Como a Legisla Brasil coleta, usa e protege dados pessoais, conforme a Lei Geral de Proteção de Dados (Lei nº 13.709/2018). Última atualização: [data]."
        title="Política de Privacidade" />
      <Section tone="surface">
        <div className="lg-prose">
          <p><strong>[Modelo: revise este texto com a assessoria jurídica antes de publicar e apague este aviso.]</strong></p>
          <h2>Quem é responsável pelos dados</h2>
          <p>Legisla Brasil, [razão social], CNPJ [nº], com sede em [endereço]. Encarregado de proteção de dados: [nome], [e-mail].</p>
          <h2>Quais dados coletamos</h2>
          <p>Nome, e-mail, telefone, cidade e informações profissionais que você envia nos formulários de contato, da Comunidade, de listas de espera e da newsletter. Em doações, os dados de pagamento são tratados pelo PayPal ou pelo seu banco, e não ficam com a Legisla.</p>
          <h2>Para que usamos</h2>
          <p>Para responder ao seu contato, organizar a Comunidade e os programas, enviar a newsletter a quem pediu e prestar contas de doações. Não vendemos nem alugamos dados.</p>
          <h2>Com quem compartilhamos</h2>
          <p>Apenas com serviços necessários para operar o site e as comunicações: [hospedagem], [ferramenta de e-mail], [serviço de formulários].</p>
          <h2>Cookies</h2>
          <p>Este site usa apenas cookies essenciais para funcionar. [Se forem usadas ferramentas de medição, liste aqui e ative um aviso de cookies com a opção de recusar.]</p>
          <h2>Por quanto tempo guardamos</h2>
          <p>Enquanto forem necessários para a finalidade informada ou até você pedir a exclusão, salvo obrigação legal. [Definir prazos.]</p>
          <h2>Seus direitos</h2>
          <p>Você pode pedir acesso, correção, exclusão ou portabilidade dos seus dados, e cancelar a newsletter a qualquer momento. Basta escrever para [e-mail do encarregado].</p>
        </div>
      </Section>
    </>
  );
}
