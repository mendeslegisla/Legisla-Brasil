import type { Metadata } from "next";
import Backdrop from "@/components/site/Backdrop";
import { Btn, Card, Grid, Head, Section, Stat } from "@/components/site/ui";
import { SITE } from "@/content/site";

export const metadata: Metadata = {
  title: "About Legisla Brasil",
  description: "Legisla Brasil is a nonpartisan, nonprofit organization that strengthens legislators, legislative staff and political parties in Brazil.",
  alternates: { canonical: "/en/" },
  openGraph: { locale: "en_US" },
};

export default function About() {
  return (
    <div lang="en">
      <section className="lg-section lg-hero has-backdrop">
        <Backdrop type="congresso" />
        <div className="lg-inner">
          <div className="lg-seq">
            <h1>We help those in politics deliver more for people.</h1>
            <p className="lg-lede">Legisla Brasil is a nonpartisan, nonprofit organization that strengthens the work of legislators, legislative staff and political parties in Brazil, so that democracy becomes more representative and effective.</p>
            <div className="lg-actions">
              <Btn arrow href="https://legislabrasil.org/wp-content/uploads/2026/07/2025-Activity-Report.pdf">Read our 2025 Activity Report</Btn>
              <Btn href={`mailto:${SITE.email}`} variant="ghost">Contact us</Btn>
            </div>
          </div>
        </div>
      </section>
      <Section tone="surface">
        <Head title="What we do" />
        <Grid cols={3}>
          <Card title="Political institutions">Strategic consulting and management tools for legislative offices at the federal, state and municipal levels, and for political parties.</Card>
          <Card title="Legisla Community">Training and a national network for legislative staff, chiefs of staff and party leaders, with a focus on underrepresented groups.</Card>
          <Card title="Knowledge">Open research and data tools, such as the Legisla Brasil Index, which tracks the performance of federal deputies.</Card>
        </Grid>
      </Section>
      <Section tone="ink">
        <Head side="Every year we publish impact reports and independent audits." title="How we are funded" />
        <Grid cols={3} min="12rem">
          <Stat label="philanthropic donations" n="70%" />
          <Stat label="services to legislative offices and parties" n="30%" />
          <Stat label="year of official registration" n="2018" />
        </Grid>
        <div className="lg-actions"><Btn href="/transparencia/#relatorios" variant="light">See all reports (in Portuguese)</Btn></div>
      </Section>
    </div>
  );
}
