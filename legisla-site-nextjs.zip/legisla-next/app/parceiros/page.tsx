import type { Metadata } from "next";
import Hero from "@/components/site/Hero";
import { Btn, Grid, Head, Section, TextLink, Wordmark } from "@/components/site/ui";
import { NETWORKS, type Partner, SUPPORTERS } from "@/content/site";

export const metadata: Metadata = {
  title: "Redes e parceiros",
  description: "Organizações que acreditam no fortalecimento democrático e constroem o trabalho da Legisla Brasil.",
  alternates: { canonical: "/parceiros/" },
};

function PartnerCard({ p }: { p: Partner }) {
  return (
    <article className="lg-card">
      <Wordmark name={p.name} />
      <h3>{p.name}</h3>
      <p className="lg-muted">{p.about}</p>
      {p.href ? <TextLink className="lg-push" href={p.href}>Visitar o site</TextLink> : <p className="lg-push lg-small">[Incluir link do site]</p>}
    </article>
  );
}

export default function Parceiros() {
  return (
    <>
      <Hero backdrop="rede" crumbs={[{ label: "Quem somos", href: "/quem-somos/" }, { label: "Redes e parceiros" }]}
        lede="Organizações que acreditam no fortalecimento democrático e constroem esse trabalho com a gente." title="Redes e parceiros" />
      <Section tone="surface">
        <Head side="Instituições filantrópicas nacionais e internacionais que financiam nosso trabalho. Os apoiadores variam a cada ano." title="Apoiadores" />
        <Grid cols={3}>{SUPPORTERS.map((p) => <PartnerCard key={p.name} p={p} />)}</Grid>
      </Section>
      <Section>
        <Head side="Organizações com quem realizamos pesquisas, programas e ações." title="Redes e parcerias" />
        <Grid cols={3}>{NETWORKS.map((p) => <PartnerCard key={p.name} p={p} />)}</Grid>
      </Section>
      <Section tone="wine">
        <h2>Quer apoiar ou construir junto?</h2>
        <p className="lg-lede">Fale com nossa equipe de parcerias sobre apoio institucional, projetos e pesquisas.</p>
        <div className="lg-actions"><Btn href="/contato/">Falar com a equipe</Btn><Btn href="/transparencia/" variant="light">Ver como usamos os recursos</Btn></div>
      </Section>
    </>
  );
}
