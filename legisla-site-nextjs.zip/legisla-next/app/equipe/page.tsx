import type { Metadata } from "next";
import Hero from "@/components/site/Hero";
import { Btn, Grid, Head, PersonCard, Section } from "@/components/site/ui";
import { CONSULTIVO, FISCAL, SITE, TEAM } from "@/content/site";

export const metadata: Metadata = {
  title: "Equipe e governança",
  description: "Quem faz a Legisla Brasil no dia a dia e quem acompanha nosso trabalho nos Conselhos Fiscal e Consultivo.",
  alternates: { canonical: "/equipe/" },
};

export default function Equipe() {
  return (
    <>
      <Hero backdrop="rede" crumbs={[{ label: "Quem somos", href: "/quem-somos/" }, { label: "Equipe e governança" }]}
        lede="Quem faz a Legisla no dia a dia e quem acompanha nosso trabalho nos Conselhos Fiscal e Consultivo."
        title="Equipe e governança" />
      <Section tone="surface"><Head title="Time Legisla" /><Grid cols={4} min="13rem">{TEAM.map((p) => <PersonCard key={p.name} p={p} />)}</Grid></Section>
      <Section><Head title="Conselho Fiscal" /><Grid cols={4} min="13rem">{FISCAL.map((p) => <PersonCard key={p.name} p={p} />)}</Grid></Section>
      <Section tone="paper"><Head title="Conselho Consultivo" /><Grid cols={4} min="13rem">{CONSULTIVO.map((p) => <PersonCard key={p.name} p={p} />)}</Grid></Section>
      <Section tone="wine">
        <h2>Quer trabalhar com a gente?</h2>
        <p className="lg-lede">Divulgamos as vagas abertas na Comunidade Legisla e no LinkedIn.</p>
        <div className="lg-actions"><Btn href={SITE.social.linkedin} variant="light">Seguir no LinkedIn</Btn></div>
      </Section>
    </>
  );
}
