import type { Metadata } from "next";
import { Crumbs } from "@/components/site/Hero";
import Form from "@/components/site/Form";
import ShapesHero from "@/components/site/ShapesHero";
import { Btn, Card, Grid, Head, Quote, Section, Steps } from "@/components/site/ui";
import { COMMUNITY_QUOTES } from "@/content/site";

export const metadata: Metadata = {
  title: "Comunidade Legisla",
  description: "Uma rede de assessores, chefes de gabinete, dirigentes partidários e parlamentares de todo o Brasil, trocando métodos, formações e oportunidades.",
  alternates: { canonical: "/comunidade/" },
};

export default function Comunidade() {
  return (
    <>
      <ShapesHero
        actions={<><Btn arrow href="#entrar">Quero fazer parte</Btn><Btn href="#niveis" variant="ghost">Como funciona</Btn></>}
        crumbs={<Crumbs items={[{ label: "Comunidade" }]} />}
        description="Uma rede de assessores, chefes de gabinete, dirigentes partidários e parlamentares de todo o Brasil, trocando métodos, formações e oportunidades."
        shapes={[
          ["Chefia de gabinete", "vinho"], ["Projeto de lei", "contorno"], ["ponto", "m", "coral"], ["Planejamento", "contorno"],
          ["bastidores", "serifa"], ["Assessoria", "tinta"], ["ponto", "p", "tinta"], ["Fiscalização", "contorno"], ["Orçamento", "contorno"],
          ["Audiência pública", "vinho"], ["ponto", "g", "coral"], ["Formação", "contorno"], ["Emenda", "tinta"], ["Mentoria", "contorno"],
          ["Representatividade", "contorno"], ["ponto", "p", "vinho"], ["Dados", "vinho"], ["pauta", "serifa"],
        ]}
        title="Os bastidores fazem a política acontecer."
      />
      <Section tone="surface">
        <Head side="Gente que redige projetos de lei, fiscaliza o Executivo e organiza partidos, em todas as regiões do país." title="Quem faz parte" />
        <Grid cols={3}>
          <Card title="Rede Legisla">Assessoras e assessores parlamentares atuantes em mandatos de todo o Brasil, com impacto local e nacional.</Card>
          <Card title="Dirigentes partidários">Lideranças que elaboram planos de governo, promovem formação política e montam as chapas eleitorais.</Card>
          <Card title="Parlamentares">Políticos de diversas ideologias e regiões, comprometidos com cumprir suas promessas de campanha.</Card>
        </Grid>
      </Section>
      <Section id="niveis" tone="ink">
        <h2>Quatro níveis de participação</h2>
        <p className="lg-lede">Você entra como Mobilizador(a) e pode avançar conforme participa.</p>
        <Steps cols={4} items={[
          { n: "1", title: "Aliados", text: <><strong>Quem são:</strong> pessoas que participaram de programas da Legisla. <strong>Participam de:</strong> dicas e formações.</> },
          { n: "2", title: "Mobilizadores", text: <><strong>Quem são:</strong> pessoas que responderam o formulário de entrada. <strong>Participam de:</strong> encontros de conexão com outros membros.</> },
          { n: "3", title: "Sherpas", text: <><strong>Quem são:</strong> mobilizadores aprovados no processo seletivo. <strong>Participam de:</strong> programa de 2 a 3 anos com formações e mentorias.</> },
          { n: "4", title: "Líderes", text: <><strong>Quem são:</strong> convidados e formados pelo programa Sherpas. <strong>Participam de:</strong> eventos de networking e o jantar anual da Legisla.</> },
        ]} />
      </Section>
      <Section>
        <Head title="O que dizem os membros" />
        <Grid cols={2} min="18rem">{COMMUNITY_QUOTES.map((q) => <Quote key={q.name} t={q} />)}</Grid>
      </Section>
      <Section id="entrar" tone="wine">
        <div className="lg-split">
          <div>
            <h2>Quero fazer parte da Comunidade</h2>
            <p className="lg-lede" style={{ marginTop: "1.25rem" }}>Pode entrar quem trabalha em mandatos, partidos ou Casas Legislativas, em qualquer lugar do Brasil.</p>
            <ul style={{ marginTop: "1rem", paddingLeft: "1.2rem", listStyle: "disc" }}>
              <li>Encontros com profissionais de outros estados</li>
              <li>Formações e dicas práticas para o dia a dia do gabinete</li>
              <li>Conexões e oportunidades para crescer na carreira política</li>
            </ul>
          </div>
          <div className="lg-form-box">
            <Form
              consent="Autorizo a Legisla a usar estes dados para contato sobre a Comunidade, conforme a"
              fields={[
                { name: "nome", label: "Nome", required: true, autoComplete: "name", pair: true },
                { name: "email", label: "E-mail", type: "email", required: true, autoComplete: "email", pair: true },
                { name: "funcao", label: "Função", type: "select", options: ["Assessor(a) parlamentar", "Chefe de gabinete", "Dirigente partidário", "Parlamentar", "Outra"], pair: true },
                { name: "cidade", label: "Cidade e UF", pair: true },
                { name: "onde", label: "Onde você trabalha?", placeholder: "Mandato, partido ou Casa legislativa" },
              ]}
              id="comunidade"
              submit="Quero fazer parte"
            />
          </div>
        </div>
      </Section>
    </>
  );
}
