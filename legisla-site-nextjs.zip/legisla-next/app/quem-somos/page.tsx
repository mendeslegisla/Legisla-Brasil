import type { Metadata } from "next";
import { Newsletter } from "@/components/site/blocks";
import Hero from "@/components/site/Hero";
import { Card, Grid, Head, Section, Timeline } from "@/components/site/ui";
import { TIMELINE } from "@/content/site";

export const metadata: Metadata = {
  title: "Quem somos",
  description: "A Legisla Brasil é uma organização suprapartidária e sem fins lucrativos que potencializa a atuação dos agentes políticos que constroem o futuro do Brasil.",
  alternates: { canonical: "/quem-somos/" },
};

export default function QuemSomos() {
  return (
    <>
      <Hero
        actions={[{ label: "Fale com a equipe", href: "/contato/", arrow: true }, { label: "Nossa história", href: "#historia", variant: "ghost" }]}
        backdrop="congresso" crumbs={[{ label: "Quem somos" }]}
        lede="A Legisla Brasil é uma organização suprapartidária e sem fins lucrativos que trabalha para potencializar a atuação e a capacidade de impacto dos agentes políticos que constroem o futuro do Brasil."
        title="Somos aliados de quem faz a política funcionar." />
      <Section tone="ink">
        <h2>Missão e visão</h2>
        <Grid cols={2} min="18rem">
          <article className="lg-card"><h3>Missão</h3><p className="lg-mission">Cultivar uma democracia representativa e efetiva, que entregue mais valor para a população.</p></article>
          <article className="lg-card"><h3>Visão</h3><p className="lg-mission">Fazer com que a população brasileira se sinta representada e confiante na sua democracia.</p></article>
        </Grid>
      </Section>
      <Section>
        <Head side="Trabalhamos com as instituições e com as pessoas que ocupam esses espaços, para gerar uma transformação em cadeia." title="O que fazemos" />
        <Grid cols={3}>
          <Card link={{ label: "Para mandatos", href: "/mandatos/" }} title="Instituições políticas">Consultorias e ferramentas para que mandatos e partidos consigam resolver e responder às principais demandas da sociedade.</Card>
          <Card link={{ label: "Conhecer a Comunidade", href: "/comunidade/" }} title="Comunidade Legisla">Formação e conexão entre profissionais com vivências diversas na política, comprometidos com a boa política.</Card>
          <Card link={{ label: "Ver pesquisas e guias", href: "/publicacoes/" }} title="Conhecimento">Decodificamos o Legislativo com dados, evidências e nossa experiência prática, em publicações acessíveis.</Card>
        </Grid>
      </Section>
      <Section tone="surface">
        <h2>Nossos valores</h2>
        <Grid cols={4} min="14rem">
          <Card title="Suprapartidarismo">Preparamos partidos, gabinetes e parlamentares para darem o seu melhor, independentemente do “time” que representam. Não atuamos a favor ou contra partidos ou espectros ideológicos.</Card>
          <Card title="Representatividade">O Brasil é enorme e plural, e só um Legislativo que espelhe essa diversidade responde aos seus desafios. Nossas iniciativas criam oportunidades para grupos sub-representados.</Card>
          <Card title="Evoluir a democracia">É o caminho para uma sociedade mais justa e desenvolvida. Por isso não trabalhamos com partidos ou mandatos antidemocráticos.</Card>
          <Card title="Otimismo e inovação">O caminho é longo, mas encaramos a realidade como ela é e acreditamos que, com pessoas realizadoras, cada barreira pode virar um trampolim.</Card>
        </Grid>
      </Section>
      <Section id="historia" tone="paper">
        <h2>Nossa história</h2>
        <Timeline items={TIMELINE} />
      </Section>
      <Section>
        <Head side="Prêmios, redes e certificações que marcam nossa trajetória." title="Reconhecimentos" />
        <Grid cols={3}>
          <Card link={{ label: "Saiba mais", href: "https://keseb.org/democracy-fellowship-cohort-2/fernando-haddad-moura/" }} title="KESEB Democracy Fellowship">Fernando Haddad Moura, diretor executivo, foi selecionado para a rede da KESEB, que conecta lideranças para fortalecer democracias. [Ano]</Card>
          <Card title="[Nome do reconhecimento]">[Ano e uma frase sobre o que foi reconhecido.]</Card>
          <Card title="[Nome do reconhecimento]">[Ano e uma frase sobre o que foi reconhecido.]</Card>
        </Grid>
      </Section>
      <Section tone="surface">
        <Head title="Conheça mais" />
        <Grid cols={3}>
          <Card link={{ label: "Ver a equipe", href: "/equipe/" }} title="Equipe e governança">Quem faz a Legisla e quem compõe os Conselhos Fiscal e Consultivo.</Card>
          <Card link={{ label: "Ver parceiros", href: "/parceiros/" }} title="Redes e parceiros">Organizações que apoiam e constroem o trabalho com a gente.</Card>
          <Card link={{ label: "Ver documentos", href: "/transparencia/" }} title="Transparência">Relatórios de impacto, auditorias, código de conduta e como nos financiamos.</Card>
        </Grid>
      </Section>
      <Newsletter />
    </>
  );
}
