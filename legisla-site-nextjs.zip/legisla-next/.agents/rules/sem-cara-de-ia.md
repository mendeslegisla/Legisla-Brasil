---
trigger: glob
globs: "app/**, components/**"
description: "O site da Legisla não pode ter cara de site gerado por IA. Vícios proibidos e o que usar no lugar."
---

# Sem cara de “site feito por IA”

## Proibido

- **Linha pequena acima do título** (“eyebrow”). O título fala sozinho; metadados vão abaixo. Isso vale também para a prop `eyebrow` dos componentes do Kokonut (exceção: trilha de navegação).
- **Cartões com fundo, sombra e borda arredondada** como estrutura de página. Use `<Card>` (coluna com fio fino em cima), `<Rows>` ou texto corrido.
- **Faixa de “número grande + rótulo”.** Números entram numa frase (`<Statement>`) ou numa ficha discreta (`<Stat>`).
- **Gradiente em texto, brilhos, vidro desfocado, listras, fundos de “aurora”.** Muitos componentes do catálogo do Kokonut são isso: não instale.
- **Setas e símbolos de texto (→, ✓) ou emoji como ícone.** Use SVG (`components/site/icons.tsx`) ou `lucide-react`.
- **Animação de entrada em toda seção.** O movimento do site é contado: título da abertura palavra por palavra, fundo da abertura se desenhando, títulos de seção assentando no peso, linha dos passos, e os componentes do Kokonut com função (marca-texto, painel de status, abas, pilha de formas, índice de rolagem).
- **Fontes batidas:** Inter, Roboto, Open Sans, Lato, Montserrat, Space Grotesk, Geist, Plus Jakarta Sans, Fraunces, Instrument Sans/Serif.
- **Rostos inventados** para pessoas reais.

## Use no lugar

- Prova real: pesquisas, manchetes da imprensa, nomes e cargos de quem foi atendido.
- Fundos desenhados do mundo do Legislativo: `<Backdrop type="hemiciclo|congresso|rede|documento">`.
- Imagens provisórias honestas: `<Portrait>`, `<Wordmark>`, `<Cover>`; fotos reais com a classe `lg-duotone`.

## Verificação

Rode o detector do Impeccable na página alterada, no computador e com `--viewport 390x844`. Meta: zero achados novos.
