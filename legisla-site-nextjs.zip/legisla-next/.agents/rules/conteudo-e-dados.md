---
trigger: model_decision
description: "Aplicar sempre que escrever ou revisar textos, números, nomes, cargos, datas ou depoimentos do site da Legisla."
---

# Conteúdo e dados

## Fatos já confirmados

- Fundada informalmente em agosto de 2017 por Luciana Elmais, Caio Rolim e Ana Kuntz; registrada em abril de 2018.
- 2021: programa O2 (Oxigenando a política brasileira). 2022: Índice Legisla Brasil e primeira edição do NEx.
- 2024: edição do NEx com 30 lideranças, focada nas eleições municipais.
- 2026: pesquisa Juventudes e Participação Partidária, formação do programa NEGRA (29 lideranças de setoriais de negritude) e 5ª edição do PLL (inscrições encerradas, programa concluído em julho).
- Direção: Fernando Moura (diretor executivo) e Lana Faria (diretora de operações). Luciana Elmais preside o Conselho.
- Financiamento: em média 70% doações e 30% venda de serviços.
- Contato: falecom@legislabrasil.org, WhatsApp +55 11 4210-6228, imprensa pela Contê (imprensa@contecomunica.com.br).

## Ainda em aberto (manter entre colchetes)

Números oficiais de mandatos, partidos e Comunidade; chave Pix; preço da consultoria; prazo de resposta; status, datas e custo do NEx e do Sherpas; ano da primeira edição do PLL; cargo de Matheus Miranda; LinkedIn pessoal de Matheus Miranda, Gabriela Lima, Synthya Maia, Lucas Mendes e Carolina Araujo; doadores do ano mais recente.

## Como escrever

- Português do Brasil, frases curtas, voz ativa.
- Depoimentos são citações literais de fontes da Legisla. Pode encurtar, nunca reescrever.
- Ao citar pesquisa, diga a fonte (“segundo a pesquisa Juventudes e Participação Partidária, da Legisla…”).
- Use “suprapartidária”, não “apartidária”.
