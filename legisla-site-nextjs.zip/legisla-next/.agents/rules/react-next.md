---
trigger: glob
globs: "app/**/*.tsx, components/**/*.tsx, content/**/*.ts"
description: "Padrões de código do site em Next.js."
---

# Código

- Componentes de servidor por padrão. `"use client"` só onde há estado, efeitos ou eventos (Header, Form, Backdrop, envoltórios do Kokonut).
- Toda página exporta `metadata` com `title`, `description` e `alternates.canonical`.
- Conteúdo nunca fica solto no JSX quando se repete ou pode mudar (números, contatos, pessoas, documentos): vai para `content/site.ts`.
- Links internos com `next/link` e barra final (`/mandatos/`); externos abrem em nova aba com `rel="noopener"` (o `<Btn>` e o `<TextLink>` já fazem isso).
- Classes Tailwind montadas dinamicamente precisam aparecer por extenso em algum lugar do código, ou não são geradas.
- Nada de bibliotecas novas sem necessidade clara. Nada de `localStorage`, cookies ou rastreadores.
- Depois de qualquer mudança: `npm run build`.
