---
name: adicionar-componente-kokonut
description: Instala e adapta um componente do Kokonut UI no site da Legisla com critério. Usar quando pedirem um componente, animação ou efeito do Kokonut.
---

# Adicionar componente do Kokonut UI

1. **Critério antes de instalar.** O componente tem uma função ligada ao mundo da Legisla (como o marca-texto e o painel de votação)? Ele não cai nos vícios da regra `sem-cara-de-ia` (gradiente em texto, brilho, vidro, aurora)? Se cair, explique e proponha uma alternativa do catálogo.
2. Instale: `npx shadcn@latest add @kokonutui/<nome>`. O arquivo vai para `components/kokonutui/`.
3. Leia a interface (props) no arquivo. Muitos exportam uma demonstração como padrão e o componente real como exportação nomeada.
4. Crie um envoltório em `components/site/` que passe cores e fontes da Legisla (`bg-vinho`, `text-tinta`, `font-titulos`…). Ajustes no próprio código do componente são permitidos: marque cada um com um comentário “Legisla:” e registre em `docs/kokonut.md`.
5. Textos em português: confira rótulos de acessibilidade (`aria-label`) e alfabetos fixos (como o do `split-flap-text`, que precisou das letras acentuadas).
6. `npm run build`, confira no navegador e rode o detector do Impeccable (contraste de cinzas padrão do Kokonut costuma ficar abaixo de 4,5:1).
