---
name: publicar
description: Publica o site da Legisla na Vercel, Netlify ou Cloudflare Pages. Usar quando pedirem para colocar o site no ar ou gerar uma versão de teste.
---

# Publicar

- **Versão de teste:** basta subir para uma branch no GitHub; a Vercel e a Netlify geram um link de pré-visualização automático.
- **Produção:** rode `npm run release`. Ele só termina sem erro se `check:launch` não encontrar pendências. Se falhar, mostre a lista à pessoa e **não contorne a trava**.
- Variáveis de ambiente na hospedagem: `NEXT_PUBLIC_SITE_URL` e `NEXT_PUBLIC_FORM_ENDPOINT` (veja `.env.example`).
- Troca de domínio (DNS de legislabrasil.org) só com confirmação explícita da pessoa. Siga a seção “Domínio” do README.
