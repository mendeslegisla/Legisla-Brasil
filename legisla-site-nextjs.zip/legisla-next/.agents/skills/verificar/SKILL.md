---
name: verificar
description: Compila o site da Legisla, confere no navegador e roda o detector do Impeccable. Usar depois de qualquer mudança ou quando pedirem para ver como o site está.
---

# Verificar

1. `npm run build`. Corrija erros de tipo antes de seguir.
2. `npx serve out` (ou `npm run dev`) e abra as páginas alteradas no navegador do Antigravity, em 1280 px e 390 px: menu, submenus, menu de celular, rolagem até o rodapé, animações, textos cortados.
3. Detector: `npx impeccable detect --json "http://localhost:3000/<rota>/"` e de novo com `--viewport 390x844`. “text-occlusion” entre pílulas da pilha de formas da Comunidade é esperado; qualquer outro achado novo deve ser corrigido.
4. `npm run check:launch` para ver as pendências de conteúdo.
