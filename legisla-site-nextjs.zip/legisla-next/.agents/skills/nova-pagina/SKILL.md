---
name: nova-pagina
description: Cria uma página nova no site da Legisla Brasil em Next.js (por exemplo, a do Programa NEGRA). Usar quando pedirem uma página, landing page ou seção nova.
---

# Criar uma página

1. Defina o público e a única ação principal no fim. Se não estiver claro, pergunte uma vez.
2. Reúna os fatos (regra `conteudo-e-dados`). O que faltar fica entre [colchetes].
3. Copie a página mais parecida: programa → `app/programa-nex/page.tsx`; serviço → `app/mandatos/page.tsx`; institucional → `app/quem-somos/page.tsx`.
4. Crie `app/<rota>/page.tsx` com `metadata` (title, description, canonical). Estrutura: `<Hero>` com trilha e fundo; 3 a 6 `<Section>` alternando tons; `<FaqList>` se houver dúvidas previsíveis; última seção `tone="wine"` com a ação.
5. Dados repetíveis vão para `content/site.ts`.
6. Ligue a página: menu (`NAV` em `content/site.ts`), rodapé (`components/site/Footer.tsx`) e `app/sitemap.ts`.
7. `npm run build`, confira no navegador (1280 px e 390 px) e rode o detector do Impeccable.
8. Entregue um resumo e a lista do que ficou entre colchetes.
